package com.example.pokemon;

public class pokemon {
    private String name;
    private int image;
    private int Attack;
    private int Defence;
    private int Total;

    public pokemon(String name, int image, int attack, int defence, int total) {
        this.name = name;
        this.image = image;
        Attack = attack;
        Defence = defence;
        Total = total;
    }

    public pokemon(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getImage() {
        return image;
    }

    public void setImage(int image) {
        this.image = image;
    }

    public int getAttack() {
        return Attack;
    }

    public void setAttack(int attack) {
        Attack = attack;
    }

    public int getDefence() {
        return Defence;
    }

    public void setDefence(int defence) {
        Defence = defence;
    }

    public int getTotal() {
        return Total;
    }

    public void setTotal(int total) {
        Total = total;
    }
}
